---
name: Crimson Edge
colors:
  surface: '#121317'
  surface-dim: '#121317'
  surface-bright: '#38393e'
  surface-container-lowest: '#0d0e12'
  surface-container-low: '#1a1b20'
  surface-container: '#1f1f24'
  surface-container-high: '#292a2e'
  surface-container-highest: '#343439'
  on-surface: '#e3e2e8'
  on-surface-variant: '#e4beba'
  inverse-surface: '#e3e2e8'
  inverse-on-surface: '#2f3035'
  outline: '#ab8985'
  outline-variant: '#5b403d'
  surface-tint: '#ffb3ac'
  primary: '#ffb3ac'
  on-primary: '#680008'
  primary-container: '#d32f2f'
  on-primary-container: '#fff2f0'
  inverse-primary: '#ba1a20'
  secondary: '#c8c6c5'
  on-secondary: '#303030'
  secondary-container: '#474746'
  on-secondary-container: '#b7b5b4'
  tertiary: '#7bd1f8'
  on-tertiary: '#003546'
  tertiary-container: '#00799c'
  on-tertiary-container: '#e9f7ff'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdad6'
  primary-fixed-dim: '#ffb3ac'
  on-primary-fixed: '#410003'
  on-primary-fixed-variant: '#930010'
  secondary-fixed: '#e5e2e1'
  secondary-fixed-dim: '#c8c6c5'
  on-secondary-fixed: '#1b1b1c'
  on-secondary-fixed-variant: '#474746'
  tertiary-fixed: '#bee9ff'
  tertiary-fixed-dim: '#7bd1f8'
  on-tertiary-fixed: '#001f2a'
  on-tertiary-fixed-variant: '#004d65'
  background: '#121317'
  on-background: '#e3e2e8'
  surface-variant: '#343439'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 40px
    fontWeight: '700'
    lineHeight: 48px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 28px
    fontWeight: '600'
    lineHeight: 36px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 8px
  container-padding-mobile: 24px
  container-padding-desktop: 48px
  gutter: 16px
  stack-sm: 12px
  stack-md: 24px
  stack-lg: 40px
---

## Brand & Style
This design system embodies high-performance computational intelligence. The aesthetic is a fusion of **Google Material You (Dark Mode)** and **High-Fidelity Glassmorphism**, creating a "Premium Technical" atmosphere. It is designed for users who value precision, speed, and cutting-edge aesthetics.

The visual language relies on a "void" philosophy: deep black surfaces that allow vibrant, glowing crimson elements to feel like they are floating in a digital ether. The emotional response is one of authority, sophistication, and focused energy.

## Colors
The palette is rooted in an **OLED-first strategy**. 
- **Primary:** Vibrant Crimson Red (#D32F2F) serves as the "energy source" for the UI, used for critical actions, status indicators, and glass tints.
- **Surface & Background:** A dual-tone dark foundation. The base background is OLED Black (#0B0C10) to minimize battery drain and maximize contrast, while Deep Charcoal (#121212) is used for secondary containers and elevated surfaces.
- **Accents:** Semantic colors for success or warning should be muted to ensure the Crimson Red remains the undisputed focal point of the experience.

## Typography
We use **Inter** across all levels to maintain a systematic, utilitarian, and modern feel. The typographic hierarchy is designed for high legibility against dark backgrounds. 

Headlines use tighter letter-spacing and heavier weights to command attention, while body text maintains generous line-heights for readability during long data-analysis sessions. All labels are strictly semi-bold or medium to prevent "vibration" on high-contrast OLED screens.

## Layout & Spacing
The layout follows a **fluid 8px grid system** with an emphasis on "negative space as a feature." 

- **Mobile:** A 4-column grid with 24px side margins to give content a premium, centered feel.
- **Desktop/Tablet:** A 12-column grid with a maximum content width of 1200px.
- **Philosophy:** Avoid crowding. Every functional group should be separated by at least 24px (stack-md) to maintain the minimalist, high-fidelity aesthetic.

## Elevation & Depth
Depth is achieved through **Glassmorphism and Tonal Layering** rather than traditional drop shadows.

1.  **Level 0 (Base):** OLED Black (#0B0C10).
2.  **Level 1 (Subtle):** Deep Charcoal (#121212) surfaces with no borders.
3.  **Level 2 (Glass):** Semi-transparent layers with a 20px backdrop-blur. These surfaces are tinted with a 10% Crimson overlay.
4.  **Accents:** A 1px "inner-glow" stroke (white or crimson at 10% opacity) should be applied to the top and left edges of glass cards to simulate physical light catching the edge of the glass.

## Shapes
The shape language is **Refined & Modern**. 
- A base radius of **0.5rem (8px)** is used for standard components like inputs and small cards.
- Larger containers and prominent glass cards use **1rem (16px)** to feel more approachable and distinct from the structural grid.
- Interactive elements like chips or pill-buttons may use the **rounded-xl (24px)** setting to indicate touchability.

## Components

### Buttons
- **Primary:** Glassmorphic Crimson. Background is `rgba(211, 47, 47, 0.2)` with a heavy 20px blur and a solid `1px` Crimson border. Text is white.
- **Secondary:** Outlined with a `1px` border of `rgba(255, 255, 255, 0.1)`.

### Cards
- Cards utilize the Level 2 Elevation glass effect. They should have no shadow, instead relying on a subtle #121212 background fill and the backdrop-blur to separate them from the Level 0 background.

### Input Fields
- Underline style or fully enclosed with a dark grey fill (#1E1E1E). On focus, the border or underline transitions to solid Crimson with a soft 4px outer glow.

### Chips & Tags
- Small, pill-shaped components. Use a dark grey base with Crimson text for high-contrast data visualization.

### Data Lists
- Dividers should be avoided where possible. Use vertical spacing (12px) and subtle surface color changes to indicate separation between list items.